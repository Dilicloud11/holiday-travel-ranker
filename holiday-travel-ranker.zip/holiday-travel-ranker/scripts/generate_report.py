#!/usr/bin/env python3
"""
Holiday Travel Ranker - Markdown Report Generator

Usage:
    python generate_report.py --input data.json --output report.md

Input JSON format:
{
  "meta": {
    "departure_city": "上海",
    "holiday": "国庆节",
    "holiday_dates": "2025-10-01 ~ 2025-10-07",
    "generated_at": "2025-09-15",
    "user_preferences": ["机票价格", "签证便利性"],
    "budget_range": "6000-10000"
  },
  "weights": {
    "flight_price": 0.20,
    "hotel_price": 0.15,
    "local_cost": 0.10,
    "visa": 0.15,
    "rating": 0.15,
    "climate": 0.10,
    "safety": 0.10,
    "experience": 0.05
  },
  "domestic": [
    {
      "rank": 1,
      "name": "成都",
      "province": "四川",
      "total_score": 8.2,
      "scores": {
        "flight_price": 8,
        "hotel_price": 7,
        "local_cost": 8,
        "visa": 10,
        "rating": 9,
        "climate": 7,
        "safety": 9,
        "experience": 9
      },
      "highlights": ["美食天堂，火锅/川菜极具吸引力", "大熊猫基地世界独一无二"],
      "warnings": ["国庆期间景点人流量极大", "部分热门餐厅需排队2小时+"],
      "best_season": "3-5月、9-11月",
      "estimated_budget": "3000-5000元/人（含往返机票+5晚住宿+日常消费）",
      "visa_info": "无需签证（国内）",
      "flight_price_ref": "往返约1200元",
      "hotel_price_ref": "中端酒店约400元/晚"
    }
  ],
  "international": [
    {
      "rank": 1,
      "name": "曼谷",
      "country": "泰国",
      "total_score": 8.5,
      "scores": { ... },
      "highlights": [...],
      "warnings": [...],
      "best_season": "...",
      "estimated_budget": "...",
      "visa_info": "...",
      "flight_price_ref": "...",
      "hotel_price_ref": "..."
    }
  ]
}

This script reads the JSON and produces a formatted Markdown report.
"""

import json
import sys
import argparse
from datetime import datetime


DIMENSION_NAMES = {
    "flight_price": "机票价格",
    "hotel_price": "酒店价格",
    "local_cost": "当地物价",
    "visa": "签证便利性",
    "rating": "旅游好评度",
    "climate": "气候适宜度",
    "safety": "安全性",
    "experience": "体验丰富度"
}

DIMENSION_ORDER = [
    "flight_price", "hotel_price", "local_cost", "visa",
    "rating", "climate", "safety", "experience"
]


def generate_report(data: dict) -> str:
    meta = data["meta"]
    weights = data["weights"]
    domestic = data.get("domestic", [])
    international = data.get("international", [])

    lines = []

    # Title
    lines.append(f"# {meta['holiday']} 旅行目的地推荐 - 从{meta['departure_city']}出发\n")
    lines.append(f"> 生成时间：{meta['generated_at']} | 出发城市：{meta['departure_city']} | 目标假期：{meta['holiday']}（{meta.get('holiday_dates', '')}）\n")

    if meta.get("user_preferences"):
        prefs = "、".join(meta["user_preferences"])
        lines.append(f"> 用户特别关注：{prefs}\n")
    if meta.get("budget_range"):
        lines.append(f"> 预算区间：{meta['budget_range']}元/人\n")

    # Scoring explanation
    lines.append("## 评分说明\n")
    lines.append("本报告基于以下 8 个维度对各目的地进行 1-10 分评分，加权计算综合分后排名。\n")
    lines.append("| 维度 | 权重 |")
    lines.append("|------|------|")
    for dim in DIMENSION_ORDER:
        w = weights.get(dim, 0)
        lines.append(f"| {DIMENSION_NAMES[dim]} | {w*100:.0f}% |")
    lines.append("")
    lines.append("评分规则：价格类维度越便宜分越高；非价格维度越好分越高。每维度满分 10 分。\n")

    # Domestic Top 10
    lines.append("---\n")
    lines.append("## 国内 Top 10 综合排名\n")
    lines.append(_build_ranking_table(domestic, is_domestic=True))
    lines.append("")

    # International Top 10
    lines.append("## 国外 Top 10 综合排名\n")
    lines.append(_build_ranking_table(international, is_domestic=False))
    lines.append("")

    # Detail cards
    lines.append("---\n")
    lines.append("## 国内目的地详细卡片\n")
    for dest in domestic:
        lines.append(_build_detail_card(dest, is_domestic=True))

    lines.append("---\n")
    lines.append("## 国外目的地详细卡片\n")
    for dest in international:
        lines.append(_build_detail_card(dest, is_domestic=False))

    # Per-dimension rankings
    lines.append("---\n")
    lines.append("## 分维度排行榜\n")
    lines.append("以下对进入 Top 10 的目的地按各单维度重新排序。\n")

    all_top = domestic + international
    for dim in DIMENSION_ORDER:
        dim_name = DIMENSION_NAMES[dim]
        if dim in ("flight_price", "hotel_price", "local_cost"):
            desc = f"（从低到高，分越高越便宜）"
        else:
            desc = f"（从高到低）"
        lines.append(f"### 按{dim_name}排序{desc}\n")
        sorted_list = sorted(all_top, key=lambda x: x["scores"].get(dim, 0), reverse=True)
        lines.append("| 排名 | 目的地 | 类型 | 该维度得分 | 综合分 |")
        lines.append("|------|--------|------|-----------|--------|")
        for i, dest in enumerate(sorted_list, 1):
            dtype = "国内" if dest.get("province") else "国外"
            location = dest.get("province") or dest.get("country", "")
            lines.append(f"| {i} | {dest['name']}（{location}） | {dtype} | {dest['scores'].get(dim, '-')} | {dest['total_score']} |")
        lines.append("")

    # Personalized advice
    if meta.get("user_preferences"):
        lines.append("---\n")
        lines.append("## 个性化建议\n")
        lines.append(f"根据你特别关注的维度（{'、'.join(meta['user_preferences'])}），以下目的地尤其值得关注：\n")
        lines.append("_（此处由 AI 根据实际评分数据生成个性化推荐语）_\n")

    # Disclaimer
    lines.append("---\n")
    lines.append("## 免责说明\n")
    lines.append("- 机票和酒店价格基于历史同期数据或近期参考价，实际价格以预订时为准。")
    lines.append("- 签证政策可能随时调整，请出行前确认最新政策。")
    lines.append("- 评分体系提供客观参考，最终决策请结合个人偏好和实际情况。\n")

    return "\n".join(lines)


def _build_ranking_table(destinations: list, is_domestic: bool) -> str:
    lines = []
    header = "| 排名 | 目的地 | " + ("省份" if is_domestic else "国家") + " | 综合分 |"
    for dim in DIMENSION_ORDER:
        header += f" {DIMENSION_NAMES[dim]} |"
    lines.append(header)

    sep = "|------|--------|" + ("------|" if True else "") + "--------|"
    for _ in DIMENSION_ORDER:
        sep += "------|"
    lines.append(sep)

    for dest in destinations:
        loc = dest.get("province", "") if is_domestic else dest.get("country", "")
        row = f"| {dest['rank']} | {dest['name']} | {loc} | **{dest['total_score']}** |"
        for dim in DIMENSION_ORDER:
            row += f" {dest['scores'].get(dim, '-')} |"
        lines.append(row)

    return "\n".join(lines)


def _build_detail_card(dest: dict, is_domestic: bool) -> str:
    lines = []
    loc = dest.get("province", "") if is_domestic else dest.get("country", "")
    lines.append(f"### {dest['rank']}. {dest['name']}（{loc}） - 综合分 {dest['total_score']}\n")

    if dest.get("highlights"):
        highlights = "；".join(dest["highlights"])
        lines.append(f"- **核心优势**：{highlights}")

    if dest.get("warnings"):
        warnings = "；".join(dest["warnings"])
        lines.append(f"- **重要劣势**：{warnings}")

    if dest.get("best_season"):
        lines.append(f"- **最佳出行时段**：{dest['best_season']}")

    if dest.get("estimated_budget"):
        lines.append(f"- **预估花费区间**：{dest['estimated_budget']}")

    if dest.get("visa_info"):
        lines.append(f"- **签证信息**：{dest['visa_info']}")

    if dest.get("flight_price_ref"):
        lines.append(f"- **参考机票价格**：{dest['flight_price_ref']}")

    if dest.get("hotel_price_ref"):
        lines.append(f"- **参考酒店价格**：{dest['hotel_price_ref']}")

    lines.append("")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Generate Markdown travel ranking report")
    parser.add_argument("--input", required=True, help="Path to input JSON data file")
    parser.add_argument("--output", required=True, help="Path to output Markdown file")
    args = parser.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)

    report = generate_report(data)

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"Report generated: {args.output}")


if __name__ == "__main__":
    main()
