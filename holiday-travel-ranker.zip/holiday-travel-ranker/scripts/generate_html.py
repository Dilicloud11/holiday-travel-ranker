#!/usr/bin/env python3
"""
Holiday Travel Ranker - Interactive HTML Report Generator

Usage:
    python generate_html.py --input data.json --output report.html

Input: Same JSON format as generate_report.py (see that file for schema).
Output: Self-contained HTML file with inline CSS + JS, no external dependencies.

Features:
- Domestic / International tab switching
- Sort by overall score or any single dimension
- Expandable detail cards for each destination
- Responsive layout, mobile-friendly
- Travel-themed color scheme
"""

import json
import sys
import argparse
import html as html_lib


DIMENSION_NAMES = {
    "flight_price": "机票价格",
    "hotel_price": "酒店价格",
    "local_cost": "当地物价",
    "visa": "签证便利性",
    "rating": "旅游好评度",
    "climate": "气候适宜度",
    "safety": "安全性",
    "experience": "体验丰富度"
}

DIMENSION_ORDER = [
    "flight_price", "hotel_price", "local_cost", "visa",
    "rating", "climate", "safety", "experience"
]

DIMENSION_ICONS = {
    "flight_price": "&#9992;",
    "hotel_price": "&#127976;",
    "local_cost": "&#128176;",
    "visa": "&#128196;",
    "rating": "&#11088;",
    "climate": "&#9728;",
    "safety": "&#128274;",
    "experience": "&#127919;"
}


def escape(text):
    """Escape text for safe HTML insertion."""
    if text is None:
        return ""
    return html_lib.escape(str(text))


def build_destination_json(destinations, is_domestic):
    """Build JS-friendly destination data array."""
    items = []
    for dest in destinations:
        item = {
            "rank": dest["rank"],
            "name": dest["name"],
            "location": dest.get("province", "") if is_domestic else dest.get("country", ""),
            "type": "domestic" if is_domestic else "international",
            "total_score": dest["total_score"],
            "scores": dest["scores"],
            "highlights": dest.get("highlights", []),
            "warnings": dest.get("warnings", []),
            "best_season": dest.get("best_season", ""),
            "estimated_budget": dest.get("estimated_budget", ""),
            "visa_info": dest.get("visa_info", ""),
            "flight_price_ref": dest.get("flight_price_ref", ""),
            "hotel_price_ref": dest.get("hotel_price_ref", "")
        }
        items.append(item)
    return items


def generate_html(data: dict) -> str:
    meta = data["meta"]
    weights = data["weights"]
    domestic = data.get("domestic", [])
    international = data.get("international", [])

    domestic_json = build_destination_json(domestic, True)
    international_json = build_destination_json(international, False)

    weights_json = json.dumps(weights, ensure_ascii=False)
    dim_names_json = json.dumps(DIMENSION_NAMES, ensure_ascii=False)
    dim_order_json = json.dumps(DIMENSION_ORDER, ensure_ascii=False)
    dim_icons_json = json.dumps(DIMENSION_ICONS, ensure_ascii=False)
    domestic_data_json = json.dumps(domestic_json, ensure_ascii=False)
    international_data_json = json.dumps(international_json, ensure_ascii=False)

    prefs = "、".join(meta.get("user_preferences", [])) or "无"
    budget = meta.get("budget_range", "不限")

    html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{escape(meta['holiday'])} 旅行推荐 - 从{escape(meta['departure_city'])}出发</title>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
  background: linear-gradient(135deg, #e8f4f8 0%, #f0e6f6 50%, #fce4ec 100%);
  min-height: 100vh;
  color: #333;
  line-height: 1.6;
}}
.container {{
  max-width: 1100px;
  margin: 0 auto;
  padding: 20px;
}}
header {{
  text-align: center;
  padding: 40px 20px 30px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-radius: 0 0 24px 24px;
  margin-bottom: 30px;
  box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
}}
header h1 {{
  font-size: 28px;
  margin-bottom: 10px;
  font-weight: 700;
}}
header .subtitle {{
  font-size: 14px;
  opacity: 0.9;
  line-height: 1.8;
}}
.meta-bar {{
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
  margin-top: 15px;
}}
.meta-tag {{
  background: rgba(255,255,255,0.2);
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 13px;
}}
.tabs {{
  display: flex;
  gap: 0;
  margin-bottom: 20px;
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}}
.tab-btn {{
  flex: 1;
  padding: 14px;
  text-align: center;
  cursor: pointer;
  font-size: 16px;
  font-weight: 600;
  border: none;
  background: white;
  color: #666;
  transition: all 0.3s;
}}
.tab-btn.active {{
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}}
.tab-btn:hover:not(.active) {{
  background: #f5f3ff;
}}
.sort-bar {{
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 20px;
  align-items: center;
}}
.sort-bar label {{
  font-size: 14px;
  font-weight: 600;
  color: #555;
  margin-right: 4px;
}}
.sort-btn {{
  padding: 6px 14px;
  border-radius: 20px;
  border: 1px solid #ddd;
  background: white;
  cursor: pointer;
  font-size: 13px;
  transition: all 0.2s;
}}
.sort-btn.active {{
  background: #667eea;
  color: white;
  border-color: #667eea;
}}
.sort-btn:hover:not(.active) {{
  border-color: #667eea;
  color: #667eea;
}}
.card-list {{
  display: flex;
  flex-direction: column;
  gap: 16px;
}}
.card {{
  background: white;
  border-radius: 16px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
  overflow: hidden;
  transition: transform 0.2s, box-shadow 0.2s;
}}
.card:hover {{
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.1);
}}
.card-header {{
  display: flex;
  align-items: center;
  padding: 16px 20px;
  cursor: pointer;
  gap: 16px;
}}
.rank-badge {{
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 18px;
  color: white;
  flex-shrink: 0;
}}
.rank-1 {{ background: linear-gradient(135deg, #f6d365, #fda085); }}
.rank-2 {{ background: linear-gradient(135deg, #a8c0ff, #3f7ef3); }}
.rank-3 {{ background: linear-gradient(135deg, #84fab0, #8fd3f4); }}
.rank-other {{ background: #ccc; }}
.card-title {{
  flex: 1;
}}
.card-title h3 {{
  font-size: 18px;
  margin-bottom: 2px;
}}
.card-title .location {{
  font-size: 13px;
  color: #999;
}}
.total-score {{
  font-size: 24px;
  font-weight: 700;
  color: #667eea;
}}
.total-score small {{
  font-size: 12px;
  color: #999;
  font-weight: 400;
}}
.score-bars {{
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 8px;
  padding: 0 20px 12px;
}}
.score-item {{
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
}}
.score-item .dim-icon {{
  width: 20px;
  text-align: center;
}}
.score-item .dim-name {{
  width: 70px;
  color: #666;
  flex-shrink: 0;
}}
.score-bar-bg {{
  flex: 1;
  height: 8px;
  background: #eee;
  border-radius: 4px;
  overflow: hidden;
}}
.score-bar-fill {{
  height: 100%;
  border-radius: 4px;
  transition: width 0.5s ease;
}}
.score-val {{
  width: 24px;
  text-align: right;
  font-weight: 600;
  color: #333;
}}
.card-detail {{
  display: none;
  padding: 0 20px 20px;
  border-top: 1px solid #f0f0f0;
  margin-top: 4px;
}}
.card-detail.open {{
  display: block;
}}
.detail-grid {{
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  margin-top: 12px;
}}
.detail-item {{
  font-size: 14px;
}}
.detail-item strong {{
  color: #555;
}}
.highlights {{
  color: #2e7d32;
}}
.warnings {{
  color: #c62828;
}}
.expand-hint {{
  font-size: 12px;
  color: #bbb;
  margin-left: auto;
  transition: transform 0.2s;
}}
.card.expanded .expand-hint {{
  transform: rotate(180deg);
}}
.weights-info {{
  background: white;
  border-radius: 16px;
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}}
.weights-info h3 {{
  margin-bottom: 12px;
  font-size: 16px;
}}
.weights-grid {{
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 8px;
}}
.weight-tag {{
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  padding: 6px 10px;
  background: #f9f7ff;
  border-radius: 8px;
}}
.weight-val {{
  font-weight: 700;
  color: #667eea;
}}
footer {{
  text-align: center;
  padding: 30px;
  color: #999;
  font-size: 13px;
}}
@media (max-width: 600px) {{
  header h1 {{ font-size: 22px; }}
  .detail-grid {{ grid-template-columns: 1fr; }}
  .score-bars {{ grid-template-columns: 1fr; }}
  .card-header {{ padding: 12px 16px; }}
}}
</style>
</head>
<body>

<header>
  <h1>{escape(meta['holiday'])} 旅行目的地推荐</h1>
  <div class="subtitle">从{escape(meta['departure_city'])}出发 | {escape(meta.get('holiday_dates', ''))}</div>
  <div class="meta-bar">
    <span class="meta-tag">生成时间：{escape(meta['generated_at'])}</span>
    <span class="meta-tag">特别关注：{escape(prefs)}</span>
    <span class="meta-tag">预算：{escape(budget)}</span>
  </div>
</header>

<div class="container">

  <div class="weights-info">
    <h3>评分权重</h3>
    <div class="weights-grid" id="weightsGrid"></div>
  </div>

  <div class="tabs">
    <button class="tab-btn active" onclick="switchTab('domestic')">国内 Top 10</button>
    <button class="tab-btn" onclick="switchTab('international')">国外 Top 10</button>
  </div>

  <div class="sort-bar">
    <label>排序：</label>
    <button class="sort-btn active" data-sort="total" onclick="sortBy('total', this)">综合分</button>
  </div>

  <div class="card-list" id="cardList"></div>

</div>

<footer>
  Holiday Travel Ranker | 数据基于历史同期参考，仅供对比，实际价格以预订时为准。
</footer>

<script>
const WEIGHTS = {weights_json};
const DIM_NAMES = {dim_names_json};
const DIM_ORDER = {dim_order_json};
const DIM_ICONS = {dim_icons_json};
const DOMESTIC = {domestic_data_json};
const INTERNATIONAL = {international_data_json};

let currentTab = 'domestic';
let currentSort = 'total';

function getScoreColor(score) {{
  if (score >= 8) return '#4caf50';
  if (score >= 6) return '#ff9800';
  if (score >= 4) return '#ff5722';
  return '#c62828';
}}

function getRankClass(rank) {{
  if (rank === 1) return 'rank-1';
  if (rank === 2) return 'rank-2';
  if (rank === 3) return 'rank-3';
  return 'rank-other';
}}

function initWeights() {{
  const grid = document.getElementById('weightsGrid');
  grid.innerHTML = DIM_ORDER.map(dim => `
    <div class="weight-tag">
      <span>${{DIM_ICONS[dim]}}</span>
      <span>${{DIM_NAMES[dim]}}</span>
      <span class="weight-val">${{(WEIGHTS[dim]*100).toFixed(0)}}%</span>
    </div>
  `).join('');
}}

function initSortButtons() {{
  const bar = document.querySelector('.sort-bar');
  DIM_ORDER.forEach(dim => {{
    const btn = document.createElement('button');
    btn.className = 'sort-btn';
    btn.dataset.sort = dim;
    btn.textContent = DIM_NAMES[dim];
    btn.onclick = function() {{ sortBy(dim, this); }};
    bar.appendChild(btn);
  }});
}}

function sortBy(key, btn) {{
  currentSort = key;
  document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderCards();
}}

function switchTab(tab) {{
  currentTab = tab;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-btn')[tab === 'domestic' ? 0 : 1].classList.add('active');
  renderCards();
}}

function getSortedData() {{
  const data = currentTab === 'domestic' ? [...DOMESTIC] : [...INTERNATIONAL];
  if (currentSort === 'total') {{
    data.sort((a, b) => b.total_score - a.total_score);
  }} else {{
    data.sort((a, b) => (b.scores[currentSort] || 0) - (a.scores[currentSort] || 0));
  }}
  return data;
}}

function toggleCard(el) {{
  const card = el.closest('.card');
  const detail = card.querySelector('.card-detail');
  card.classList.toggle('expanded');
  detail.classList.toggle('open');
}}

function renderCards() {{
  const data = getSortedData();
  const list = document.getElementById('cardList');

  list.innerHTML = data.map((dest, idx) => {{
    const rank = idx + 1;
    const highlightsHtml = dest.highlights.map(h => `<span class="highlights">&bull; ${{h}}</span>`).join('<br>');
    const warningsHtml = dest.warnings.map(w => `<span class="warnings">&bull; ${{w}}</span>`).join('<br>');

    const scoreBarsHtml = DIM_ORDER.map(dim => {{
      const score = dest.scores[dim] || 0;
      const pct = score * 10;
      const color = getScoreColor(score);
      return `
        <div class="score-item">
          <span class="dim-icon">${{DIM_ICONS[dim]}}</span>
          <span class="dim-name">${{DIM_NAMES[dim]}}</span>
          <div class="score-bar-bg"><div class="score-bar-fill" style="width:${{pct}}%;background:${{color}}"></div></div>
          <span class="score-val">${{score}}</span>
        </div>`;
    }}).join('');

    return `
      <div class="card">
        <div class="card-header" onclick="toggleCard(this)">
          <div class="rank-badge ${{getRankClass(rank)}}">${{rank}}</div>
          <div class="card-title">
            <h3>${{dest.name}}</h3>
            <span class="location">${{dest.location}}</span>
          </div>
          <div class="total-score">${{dest.total_score}}<small>/10</small></div>
          <span class="expand-hint">&#9660;</span>
        </div>
        <div class="score-bars">${{scoreBarsHtml}}</div>
        <div class="card-detail">
          <div class="detail-grid">
            <div class="detail-item"><strong>核心优势：</strong><br>${{highlightsHtml || '-'}}</div>
            <div class="detail-item"><strong>重要劣势：</strong><br>${{warningsHtml || '-'}}</div>
            <div class="detail-item"><strong>最佳出行时段：</strong> ${{dest.best_season || '-'}}</div>
            <div class="detail-item"><strong>预估花费：</strong> ${{dest.estimated_budget || '-'}}</div>
            <div class="detail-item"><strong>签证信息：</strong> ${{dest.visa_info || '-'}}</div>
            <div class="detail-item"><strong>参考机票：</strong> ${{dest.flight_price_ref || '-'}}</div>
            <div class="detail-item"><strong>参考酒店：</strong> ${{dest.hotel_price_ref || '-'}}</div>
          </div>
        </div>
      </div>`;
  }}).join('');
}}

// Init
initWeights();
initSortButtons();
renderCards();
</script>
</body>
</html>"""

    return html_content


def main():
    parser = argparse.ArgumentParser(description="Generate interactive HTML travel ranking report")
    parser.add_argument("--input", required=True, help="Path to input JSON data file")
    parser.add_argument("--output", required=True, help="Path to output HTML file")
    args = parser.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)

    html_output = generate_html(data)

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(html_output)

    print(f"HTML report generated: {args.output}")


if __name__ == "__main__":
    main()
